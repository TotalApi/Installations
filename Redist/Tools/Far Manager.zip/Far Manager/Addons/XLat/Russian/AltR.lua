Macro {
  area="Common"; key="AltR"; description="Use hotkey <Alt-R> to perform XLat function."; flags=""; action = function()
Keys('xlat')
  end;
}

