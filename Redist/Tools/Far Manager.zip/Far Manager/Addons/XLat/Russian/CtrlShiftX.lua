Macro {
  area="Common"; key="CtrlShiftX"; description="Use hotkey <Ctrl-Shift-X> to perform XLat function."; flags=""; action = function()
Keys('xlat')
  end;
}

