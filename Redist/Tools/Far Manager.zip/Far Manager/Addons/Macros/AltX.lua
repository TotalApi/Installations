Macro {
  area="Editor Viewer"; key="AltX"; description="Close editor or viewer"; action = function()
Keys('F10')
  end;
}

Macro {
  area="Search Shell"; key="AltX"; description="Exit FAR"; action = function()
Keys('F10')
  end;
}
