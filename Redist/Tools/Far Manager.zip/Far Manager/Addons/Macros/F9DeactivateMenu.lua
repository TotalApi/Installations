Macro {
  area="MainMenu"; key="F9"; description="Use F9 to deactivate main menu"; action = function()
Keys('Esc')
  end;
}

