Macro {
  area="Editor"; key="CtrlF10"; description="Quit from editor and position to the current file"; action = function()
Keys('CtrlF10 Esc')
  end;
}

Macro {
  area="Viewer"; key="CtrlF10"; description="Quit from viewer and position to the current file"; action = function()
Keys('CtrlF10 Esc')
  end;
}

