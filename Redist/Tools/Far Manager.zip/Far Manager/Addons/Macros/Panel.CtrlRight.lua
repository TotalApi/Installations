Macro {
  area="Shell"; key="CtrlRight"; flags="EmptyCommandLine"; description="Use Ctrl-Right to change current drive to the next"; action = function()
Keys('F9 Enter Up Enter Down Enter Esc')
  end;
}

