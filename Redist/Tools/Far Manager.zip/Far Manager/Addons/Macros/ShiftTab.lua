Macro {
  area="Editor Shell Viewer"; key="ShiftTab"; description="^Ctrl-Tab"; action = function()
Keys('CtrlShiftTab')
  end;
}
