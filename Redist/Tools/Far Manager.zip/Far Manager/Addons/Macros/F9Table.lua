Macro {
  area="Viewer Editor"; key="F9"; description="Use F9 to change current table in viewer and editor"; action = function()
Keys('ShiftF8 Down Enter')
  end;
}
